package com.robot.pojo;

import java.math.BigDecimal;
import java.util.Date;

public class FlowRuleT {
    private BigDecimal id;

    private BigDecimal subflowId;

    private String nodeId;

    private String nodeName;

    private String nodeType;

    private String aboveNodeId;

    private String flowCondition1;

    private String flowCondition2;

    private String flowCondition3;

    private String flowCondition4;

    private String flowCondition5;

    private String flowCondition6;

    private String flowCondition7;

    private String flowCondition8;

    private String flowCondition9;

    private String flowCondition10;

    private String flowCondition11;

    private String flowCondition12;

    private String flowCondition13;

    private String flowCondition14;

    private String flowCondition15;

    private String flowCondition16;

    private String flowCondition17;

    private String flowCondition18;

    private String flowCondition19;

    private String flowCondition20;

    private String flowCondition21;

    private String flowCondition22;

    private String flowCondition23;

    private String flowCondition24;

    private String flowCondition25;

    private String flowCondition26;

    private String flowCondition27;

    private String flowCondition28;

    private String flowCondition29;

    private String flowCondition30;

    private String flowCondition31;

    private String flowCondition32;

    private String flowCondition33;

    private String flowCondition34;

    private String flowCondition35;

    private String flowCondition36;

    private String flowCondition37;

    private String flowCondition38;

    private String flowCondition39;

    private String flowCondition40;

    private String flowCondition41;

    private String flowCondition42;

    private String flowCondition43;

    private String flowCondition44;

    private String flowCondition45;

    private String flowCondition46;

    private String flowCondition47;

    private String flowCondition48;

    private String flowCondition49;

    private String flowCondition50;

    private String ruleType;

    private String questionCategory;

    private String normalQuestion;

    private String nextSubflowId;

    private String nextNodeId;

    private String cityCode;

    private BigDecimal createBy;

    private Date createTime;

    private BigDecimal updateBy;

    private Date updateTime;

    private Boolean remove;

    private String ruleResponse;

    public BigDecimal getId() {
        return id;
    }

    public void setId(BigDecimal id) {
        this.id = id;
    }

    public BigDecimal getSubflowId() {
        return subflowId;
    }

    public void setSubflowId(BigDecimal subflowId) {
        this.subflowId = subflowId;
    }

    public String getNodeId() {
        return nodeId;
    }

    public void setNodeId(String nodeId) {
        this.nodeId = nodeId == null ? null : nodeId.trim();
    }

    public String getNodeName() {
        return nodeName;
    }

    public void setNodeName(String nodeName) {
        this.nodeName = nodeName == null ? null : nodeName.trim();
    }

    public String getNodeType() {
        return nodeType;
    }

    public void setNodeType(String nodeType) {
        this.nodeType = nodeType == null ? null : nodeType.trim();
    }

    public String getAboveNodeId() {
        return aboveNodeId;
    }

    public void setAboveNodeId(String aboveNodeId) {
        this.aboveNodeId = aboveNodeId == null ? null : aboveNodeId.trim();
    }

    public String getFlowCondition1() {
        return flowCondition1;
    }

    public void setFlowCondition1(String flowCondition1) {
        this.flowCondition1 = flowCondition1 == null ? null : flowCondition1.trim();
    }

    public String getFlowCondition2() {
        return flowCondition2;
    }

    public void setFlowCondition2(String flowCondition2) {
        this.flowCondition2 = flowCondition2 == null ? null : flowCondition2.trim();
    }

    public String getFlowCondition3() {
        return flowCondition3;
    }

    public void setFlowCondition3(String flowCondition3) {
        this.flowCondition3 = flowCondition3 == null ? null : flowCondition3.trim();
    }

    public String getFlowCondition4() {
        return flowCondition4;
    }

    public void setFlowCondition4(String flowCondition4) {
        this.flowCondition4 = flowCondition4 == null ? null : flowCondition4.trim();
    }

    public String getFlowCondition5() {
        return flowCondition5;
    }

    public void setFlowCondition5(String flowCondition5) {
        this.flowCondition5 = flowCondition5 == null ? null : flowCondition5.trim();
    }

    public String getFlowCondition6() {
        return flowCondition6;
    }

    public void setFlowCondition6(String flowCondition6) {
        this.flowCondition6 = flowCondition6 == null ? null : flowCondition6.trim();
    }

    public String getFlowCondition7() {
        return flowCondition7;
    }

    public void setFlowCondition7(String flowCondition7) {
        this.flowCondition7 = flowCondition7 == null ? null : flowCondition7.trim();
    }

    public String getFlowCondition8() {
        return flowCondition8;
    }

    public void setFlowCondition8(String flowCondition8) {
        this.flowCondition8 = flowCondition8 == null ? null : flowCondition8.trim();
    }

    public String getFlowCondition9() {
        return flowCondition9;
    }

    public void setFlowCondition9(String flowCondition9) {
        this.flowCondition9 = flowCondition9 == null ? null : flowCondition9.trim();
    }

    public String getFlowCondition10() {
        return flowCondition10;
    }

    public void setFlowCondition10(String flowCondition10) {
        this.flowCondition10 = flowCondition10 == null ? null : flowCondition10.trim();
    }

    public String getFlowCondition11() {
        return flowCondition11;
    }

    public void setFlowCondition11(String flowCondition11) {
        this.flowCondition11 = flowCondition11 == null ? null : flowCondition11.trim();
    }

    public String getFlowCondition12() {
        return flowCondition12;
    }

    public void setFlowCondition12(String flowCondition12) {
        this.flowCondition12 = flowCondition12 == null ? null : flowCondition12.trim();
    }

    public String getFlowCondition13() {
        return flowCondition13;
    }

    public void setFlowCondition13(String flowCondition13) {
        this.flowCondition13 = flowCondition13 == null ? null : flowCondition13.trim();
    }

    public String getFlowCondition14() {
        return flowCondition14;
    }

    public void setFlowCondition14(String flowCondition14) {
        this.flowCondition14 = flowCondition14 == null ? null : flowCondition14.trim();
    }

    public String getFlowCondition15() {
        return flowCondition15;
    }

    public void setFlowCondition15(String flowCondition15) {
        this.flowCondition15 = flowCondition15 == null ? null : flowCondition15.trim();
    }

    public String getFlowCondition16() {
        return flowCondition16;
    }

    public void setFlowCondition16(String flowCondition16) {
        this.flowCondition16 = flowCondition16 == null ? null : flowCondition16.trim();
    }

    public String getFlowCondition17() {
        return flowCondition17;
    }

    public void setFlowCondition17(String flowCondition17) {
        this.flowCondition17 = flowCondition17 == null ? null : flowCondition17.trim();
    }

    public String getFlowCondition18() {
        return flowCondition18;
    }

    public void setFlowCondition18(String flowCondition18) {
        this.flowCondition18 = flowCondition18 == null ? null : flowCondition18.trim();
    }

    public String getFlowCondition19() {
        return flowCondition19;
    }

    public void setFlowCondition19(String flowCondition19) {
        this.flowCondition19 = flowCondition19 == null ? null : flowCondition19.trim();
    }

    public String getFlowCondition20() {
        return flowCondition20;
    }

    public void setFlowCondition20(String flowCondition20) {
        this.flowCondition20 = flowCondition20 == null ? null : flowCondition20.trim();
    }

    public String getFlowCondition21() {
        return flowCondition21;
    }

    public void setFlowCondition21(String flowCondition21) {
        this.flowCondition21 = flowCondition21 == null ? null : flowCondition21.trim();
    }

    public String getFlowCondition22() {
        return flowCondition22;
    }

    public void setFlowCondition22(String flowCondition22) {
        this.flowCondition22 = flowCondition22 == null ? null : flowCondition22.trim();
    }

    public String getFlowCondition23() {
        return flowCondition23;
    }

    public void setFlowCondition23(String flowCondition23) {
        this.flowCondition23 = flowCondition23 == null ? null : flowCondition23.trim();
    }

    public String getFlowCondition24() {
        return flowCondition24;
    }

    public void setFlowCondition24(String flowCondition24) {
        this.flowCondition24 = flowCondition24 == null ? null : flowCondition24.trim();
    }

    public String getFlowCondition25() {
        return flowCondition25;
    }

    public void setFlowCondition25(String flowCondition25) {
        this.flowCondition25 = flowCondition25 == null ? null : flowCondition25.trim();
    }

    public String getFlowCondition26() {
        return flowCondition26;
    }

    public void setFlowCondition26(String flowCondition26) {
        this.flowCondition26 = flowCondition26 == null ? null : flowCondition26.trim();
    }

    public String getFlowCondition27() {
        return flowCondition27;
    }

    public void setFlowCondition27(String flowCondition27) {
        this.flowCondition27 = flowCondition27 == null ? null : flowCondition27.trim();
    }

    public String getFlowCondition28() {
        return flowCondition28;
    }

    public void setFlowCondition28(String flowCondition28) {
        this.flowCondition28 = flowCondition28 == null ? null : flowCondition28.trim();
    }

    public String getFlowCondition29() {
        return flowCondition29;
    }

    public void setFlowCondition29(String flowCondition29) {
        this.flowCondition29 = flowCondition29 == null ? null : flowCondition29.trim();
    }

    public String getFlowCondition30() {
        return flowCondition30;
    }

    public void setFlowCondition30(String flowCondition30) {
        this.flowCondition30 = flowCondition30 == null ? null : flowCondition30.trim();
    }

    public String getFlowCondition31() {
        return flowCondition31;
    }

    public void setFlowCondition31(String flowCondition31) {
        this.flowCondition31 = flowCondition31 == null ? null : flowCondition31.trim();
    }

    public String getFlowCondition32() {
        return flowCondition32;
    }

    public void setFlowCondition32(String flowCondition32) {
        this.flowCondition32 = flowCondition32 == null ? null : flowCondition32.trim();
    }

    public String getFlowCondition33() {
        return flowCondition33;
    }

    public void setFlowCondition33(String flowCondition33) {
        this.flowCondition33 = flowCondition33 == null ? null : flowCondition33.trim();
    }

    public String getFlowCondition34() {
        return flowCondition34;
    }

    public void setFlowCondition34(String flowCondition34) {
        this.flowCondition34 = flowCondition34 == null ? null : flowCondition34.trim();
    }

    public String getFlowCondition35() {
        return flowCondition35;
    }

    public void setFlowCondition35(String flowCondition35) {
        this.flowCondition35 = flowCondition35 == null ? null : flowCondition35.trim();
    }

    public String getFlowCondition36() {
        return flowCondition36;
    }

    public void setFlowCondition36(String flowCondition36) {
        this.flowCondition36 = flowCondition36 == null ? null : flowCondition36.trim();
    }

    public String getFlowCondition37() {
        return flowCondition37;
    }

    public void setFlowCondition37(String flowCondition37) {
        this.flowCondition37 = flowCondition37 == null ? null : flowCondition37.trim();
    }

    public String getFlowCondition38() {
        return flowCondition38;
    }

    public void setFlowCondition38(String flowCondition38) {
        this.flowCondition38 = flowCondition38 == null ? null : flowCondition38.trim();
    }

    public String getFlowCondition39() {
        return flowCondition39;
    }

    public void setFlowCondition39(String flowCondition39) {
        this.flowCondition39 = flowCondition39 == null ? null : flowCondition39.trim();
    }

    public String getFlowCondition40() {
        return flowCondition40;
    }

    public void setFlowCondition40(String flowCondition40) {
        this.flowCondition40 = flowCondition40 == null ? null : flowCondition40.trim();
    }

    public String getFlowCondition41() {
        return flowCondition41;
    }

    public void setFlowCondition41(String flowCondition41) {
        this.flowCondition41 = flowCondition41 == null ? null : flowCondition41.trim();
    }

    public String getFlowCondition42() {
        return flowCondition42;
    }

    public void setFlowCondition42(String flowCondition42) {
        this.flowCondition42 = flowCondition42 == null ? null : flowCondition42.trim();
    }

    public String getFlowCondition43() {
        return flowCondition43;
    }

    public void setFlowCondition43(String flowCondition43) {
        this.flowCondition43 = flowCondition43 == null ? null : flowCondition43.trim();
    }

    public String getFlowCondition44() {
        return flowCondition44;
    }

    public void setFlowCondition44(String flowCondition44) {
        this.flowCondition44 = flowCondition44 == null ? null : flowCondition44.trim();
    }

    public String getFlowCondition45() {
        return flowCondition45;
    }

    public void setFlowCondition45(String flowCondition45) {
        this.flowCondition45 = flowCondition45 == null ? null : flowCondition45.trim();
    }

    public String getFlowCondition46() {
        return flowCondition46;
    }

    public void setFlowCondition46(String flowCondition46) {
        this.flowCondition46 = flowCondition46 == null ? null : flowCondition46.trim();
    }

    public String getFlowCondition47() {
        return flowCondition47;
    }

    public void setFlowCondition47(String flowCondition47) {
        this.flowCondition47 = flowCondition47 == null ? null : flowCondition47.trim();
    }

    public String getFlowCondition48() {
        return flowCondition48;
    }

    public void setFlowCondition48(String flowCondition48) {
        this.flowCondition48 = flowCondition48 == null ? null : flowCondition48.trim();
    }

    public String getFlowCondition49() {
        return flowCondition49;
    }

    public void setFlowCondition49(String flowCondition49) {
        this.flowCondition49 = flowCondition49 == null ? null : flowCondition49.trim();
    }

    public String getFlowCondition50() {
        return flowCondition50;
    }

    public void setFlowCondition50(String flowCondition50) {
        this.flowCondition50 = flowCondition50 == null ? null : flowCondition50.trim();
    }

    public String getRuleType() {
        return ruleType;
    }

    public void setRuleType(String ruleType) {
        this.ruleType = ruleType == null ? null : ruleType.trim();
    }

    public String getQuestionCategory() {
        return questionCategory;
    }

    public void setQuestionCategory(String questionCategory) {
        this.questionCategory = questionCategory == null ? null : questionCategory.trim();
    }

    public String getNormalQuestion() {
        return normalQuestion;
    }

    public void setNormalQuestion(String normalQuestion) {
        this.normalQuestion = normalQuestion == null ? null : normalQuestion.trim();
    }

    public String getNextSubflowId() {
        return nextSubflowId;
    }

    public void setNextSubflowId(String nextSubflowId) {
        this.nextSubflowId = nextSubflowId == null ? null : nextSubflowId.trim();
    }

    public String getNextNodeId() {
        return nextNodeId;
    }

    public void setNextNodeId(String nextNodeId) {
        this.nextNodeId = nextNodeId == null ? null : nextNodeId.trim();
    }

    public String getCityCode() {
        return cityCode;
    }

    public void setCityCode(String cityCode) {
        this.cityCode = cityCode == null ? null : cityCode.trim();
    }

    public BigDecimal getCreateBy() {
        return createBy;
    }

    public void setCreateBy(BigDecimal createBy) {
        this.createBy = createBy;
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public BigDecimal getUpdateBy() {
        return updateBy;
    }

    public void setUpdateBy(BigDecimal updateBy) {
        this.updateBy = updateBy;
    }

    public Date getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(Date updateTime) {
        this.updateTime = updateTime;
    }

    public Boolean getRemove() {
        return remove;
    }

    public void setRemove(Boolean remove) {
        this.remove = remove;
    }

    public String getRuleResponse() {
        return ruleResponse;
    }

    public void setRuleResponse(String ruleResponse) {
        this.ruleResponse = ruleResponse == null ? null : ruleResponse.trim();
    }
}